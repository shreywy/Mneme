# CPS721

Notes for **Artificial Intelligence I**.

- Week 1: propositional logic
- Week 2: first-order logic
